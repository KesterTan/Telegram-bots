const startMessage = `
Welcome to Search Bot!
Use the inline query mode:
@Search2112bot p <search image>
@Search2112bot w <search wiki>
`;

module.exports = {
    startMessage
}